# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['crim_intervals']

package_data = \
{'': ['*']}

install_requires = \
['certifi==2020.12.5',
 'chardet==4.0.0',
 'h11==0.12.0',
 'httpcore==0.13.2',
 'httpx==0.18.1',
 'idna==3.1',
 'joblib==1.0.1',
 'lxml==4.6.3',
 'more-itertools==8.7.0',
 'music21==6.7.1',
 'numpy==1.20.2',
 'pandas==1.2.4',
 'python-dateutil==2.8.1',
 'pytz==2021.1',
 'rfc3986==1.4.0',
 'six==1.15.0',
 'sniffio==1.2.0',
 'webcolors==1.11.1']

setup_kwargs = {
    'name': 'crim-intervals',
    'version': '0.3.3',
    'description': '',
    'long_description': None,
    'author': 'Freddie Gould',
    'author_email': 'fgould@haverford.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7.1,<4.0',
}


setup(**setup_kwargs)
